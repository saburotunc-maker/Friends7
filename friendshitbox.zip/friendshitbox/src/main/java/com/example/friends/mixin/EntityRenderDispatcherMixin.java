package com.example.friends.mixin;

import com.example.friends.FriendsMod;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private <E extends Entity> void friendBox(E entity, double x, double y, double z,
            float yaw, float tickDelta, MatrixStack matrices,
            VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (!(entity instanceof PlayerEntity p) || !FriendsMod.isFriend(p)) return;
        Box box = entity.getBoundingBox()
            .offset(-entity.getX(), -entity.getY(), -entity.getZ());
        matrices.push();
        matrices.translate(x, y, z);
        WorldRenderer.drawBox(matrices, vcp.getBuffer(RenderLayer.getLines()), box, 0f, 1f, 0f, 1f);
        matrices.pop();
    }
}
