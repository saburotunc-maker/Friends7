package com.example.friends;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

public class FriendsMod implements ClientModInitializer {
    public static final Set<String> FRIENDS = new HashSet<>();
    static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("friends.txt");

    public static boolean isFriend(PlayerEntity p) {
        return FRIENDS.contains(p.getName().getString().toLowerCase());
    }

    @Override
    public void onInitializeClient() {
        try { if (Files.exists(FILE)) FRIENDS.addAll(Files.readAllLines(FILE)); } catch (Exception ignored) {}

        ClientCommandRegistrationCallback.EVENT.register((d, reg) -> d.register(
            ClientCommandManager.literal("friends")
                .then(ClientCommandManager.literal("add")
                    .then(ClientCommandManager.argument("isim", StringArgumentType.word())
                        .executes(c -> {
                            String n = StringArgumentType.getString(c, "isim").toLowerCase();
                            FRIENDS.add(n); save();
                            c.getSource().sendFeedback(Text.literal("Eklendi: " + n));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("remove")
                    .then(ClientCommandManager.argument("isim", StringArgumentType.word())
                        .executes(c -> {
                            String n = StringArgumentType.getString(c, "isim").toLowerCase();
                            FRIENDS.remove(n); save();
                            c.getSource().sendFeedback(Text.literal("Silindi: " + n));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("list")
                    .executes(c -> {
                        c.getSource().sendFeedback(Text.literal("Friends: " + FRIENDS));
                        return 1;
                    }))));
    }

    static void save() {
        try { Files.write(FILE, FRIENDS); } catch (Exception ignored) {}
    }
}
